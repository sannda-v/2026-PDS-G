# Projects in Data Science - Exercises Repo
Excercises description and useful resources will be added throughout the course.

## Week 1: TBA

